<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>cardozo engineering, inc.</title>
<link href="./cardozo_styles.css" rel="stylesheet" type="text/css">

<link rel="apple-touch-icon" sizes="180x180" href="./images/logos/apple-touch-icon.png">
<link rel="icon" type="image/png" sizes="32x32" href="./images/logos/favicon-32x32.png">
<link rel="icon" type="image/png" sizes="16x16" href="./images/logos/favicon-16x16.png">
<link rel="manifest" href="./images/logos/site.webmanifest">
<link rel="mask-icon" href="./images/logos/safari-pinned-tab.svg" color="#5bbad5">
<link rel="shortcut icon" href="./images/logos/favicon.ico">
<meta name="msapplication-TileColor" content="#da532c">
<meta name="msapplication-config" content="./images/logos/browserconfig.xml">
<meta name="theme-color" content="#ffffff">

<script type="text/javascript">
<!--

function newImage(arg) {
	if (document.images) {
		rslt = new Image();
		rslt.src = arg;
		return rslt;
	}
}

function changeImages() {
	if (document.images && (preloadFlag == true)) {
		for (var i=0; i<changeImages.arguments.length; i+=2) {
			document[changeImages.arguments[i]].src = changeImages.arguments[i+1];
		}
	}
}

var preloadFlag = false;
function preloadImages() {
	if (document.images) {
		card_rollovers_06_over = newImage("images/card_rollovers_06-over.jpg");
		card_rollovers_07_over = newImage("images/card_rollovers_07-over.jpg");
		card_rollovers_08_over = newImage("images/card_rollovers_08-over.jpg");
		card_rollovers_09_over = newImage("images/card_rollovers_09-over.jpg");
		card_rollovers_10_over = newImage("images/card_rollovers_10-over.jpg");
		preloadFlag = true;
	}
}

// -->
</script>
</head>
<body onLoad="preloadImages();">
<table border="0" align="center" cellpadding="0" cellspacing="0" bgcolor="#FFFFFF" width="800">
  <tr>
    <td width="578" height="127"><a href="./home.php"><img src="./images/cardozo_topbanner.jpg" alt="cardozo engineering" width="578" height="127" border="0" /></a></td>
    <td><img src="./images/Water.gif" width="222" height="127" /></td>
  </tr>
  <tr background="./images/cardozo_top_nav_bg.jpg">
    <td height="28" colspan="2" class="tdTOPnav">
	<table border="0" cellspacing="0" cellpadding="0">
  <tr height="28" background="./images/cardozo_top_nav_bg.jpg">
    <td width="145" class="tdTOPnav">&nbsp;</td>
<td height="28" class="tdTOPnav">
<a href="./page_handler.php?p=0&s=0" class="primNav">Home</a>
	</td>
				<td height="28"><img src="images/cardozo_top_nav_midbar.jpg" width="3" height="28"></td>
		<td height="28" class="tdTOPnav">
<a href="./page_handler.php?p=1&s=0" class="primNav">Services</a>
	</td>
				<td height="28"><img src="images/cardozo_top_nav_midbar.jpg" width="3" height="28"></td>
		<td height="28" class="tdTOPnav">
<a href="./page_handler.php?p=2&s=0" class="primNav">Projects</a>
	</td>
				<td height="28"><img src="images/cardozo_top_nav_midbar.jpg" width="3" height="28"></td>
		<td height="28" class="tdTOPnav">
<a href="./page_handler.php?p=3&s=0" class="primNav">Careers</a>
	</td>
				<td height="28"><img src="images/cardozo_top_nav_midbar.jpg" width="3" height="28"></td>
		<td height="28" class="tdTOPnav">
<a href="./page_handler.php?p=4&s=0" class="primNav">Teaming</a>
	</td>
				<td height="28"><img src="images/cardozo_top_nav_midbar.jpg" width="3" height="28"></td>
		<td height="28" class="tdTOPnav">
<a href="./page_handler.php?p=5&s=0" class="primNav">Contact Us</a>
	</td>
		  </tr>
</table>	</td>
  </tr>
  <tr>
    <td height="33" colspan="2" background="./images/cardozo_top_nav_separator.jpg"><img src="images/cardozo_top_nav_separator.jpg" width="7" height="33" /></td>
  </tr>
  <tr>
    <td height="28" colspan="2">
	<video autoplay loop muted playsinline>
    		<source src="CardozoHOMEanim.mp4" type="video/mp4">
	</video>
        <param name="movie" value="./CardozoHOMEanim.mp4>
	</td>
  </tr>
  <tr>
    <td height="25" colspan="2">&nbsp;</td>
  </tr>
  <tr>
    <td height="28" colspan="2"><table border="0" cellspacing="0" cellpadding="4">
      <tr>
        <td align="center" valign="top">
		<style type="text/css">
<!--
.style1 {
	font-size: 12px;
	font-weight: bold;
	font-family: Arial, Helvetica, sans-serif;
	color: #FFFFFF;
}
-->
</style>
<table id="Table_01" width="391" height="173" border="0" cellpadding="0" cellspacing="0">
	<tr>
		<td background="./images/card_rollovers_01.jpg" width="78" height="24">
		<div align="center" class="style1">Sewers</div>
		</td>
		<td background="./images/card_rollovers_02.jpg" width="78" height="24">
		<div align="center" class="style1">Storm water</div>
		</td>
		<td background="./images/card_rollovers_03.jpg" width="78" height="24">
		<div align="center" class="style1">Waste water</div>
		</td>
		<td background="./images/card_rollovers_04.jpg" width="78" height="24">
		<div align="center" class="style1">Water</div>
		</td>
		<td background="./images/card_rollovers_05.jpg" width="78" height="24">
		<div align="center" class="style1">Civil Eng.</div>
		</td>
	</tr>
	<tr>
		<td>
			<a href="page_handler.php?p=2&s=0"
				onmouseover="changeImages('card_rollovers_06', './images/card_rollovers_06-over.jpg'); return true;"
				onmouseout="changeImages('card_rollovers_06', './images/card_rollovers_06.jpg'); return true;"
				onmousedown="changeImages('card_rollovers_06', './images/card_rollovers_06-over.jpg'); return true;"
				onmouseup="changeImages('card_rollovers_06', './images/card_rollovers_06-over.jpg'); return true;">
				<img name="card_rollovers_06" src="./images/card_rollovers_06.jpg" width="78" height="149" border="0" alt="Alternate01"></a></td>
		<td>
			<a href="page_handler.php?p=2&s=0"
				onmouseover="changeImages('card_rollovers_07', './images/card_rollovers_07-over.jpg'); return true;"
				onmouseout="changeImages('card_rollovers_07', './images/card_rollovers_07.jpg'); return true;"
				onmousedown="changeImages('card_rollovers_07', './images/card_rollovers_07-over.jpg'); return true;"
				onmouseup="changeImages('card_rollovers_07', './images/card_rollovers_07-over.jpg'); return true;">
				<img name="card_rollovers_07" src="images/card_rollovers_07.jpg" width="78" height="149" border="0" alt="Alternate02"></a></td>
		<td>
			<a href="page_handler.php?p=2&s=0"
				onmouseover="changeImages('card_rollovers_08', './images/card_rollovers_08-over.jpg'); return true;"
				onmouseout="changeImages('card_rollovers_08', './images/card_rollovers_08.jpg'); return true;"
				onmousedown="changeImages('card_rollovers_08', './images/card_rollovers_08-over.jpg'); return true;"
				onmouseup="changeImages('card_rollovers_08', './images/card_rollovers_08-over.jpg'); return true;">
				<img name="card_rollovers_08" src="images/card_rollovers_08.jpg" width="78" height="149" border="0" alt="Alternate03"></a></td>
		<td>
			<a href="page_handler.php?p=2&s=0"
				onmouseover="changeImages('card_rollovers_09', './images/card_rollovers_09-over.jpg'); return true;"
				onmouseout="changeImages('card_rollovers_09', './images/card_rollovers_09.jpg'); return true;"
				onmousedown="changeImages('card_rollovers_09', './images/card_rollovers_09-over.jpg'); return true;"
				onmouseup="changeImages('card_rollovers_09', './images/card_rollovers_09-over.jpg'); return true;">
				<img name="card_rollovers_09" src="images/card_rollovers_09.jpg" width="78" height="149" border="0" alt="Alternate04"></a></td>
		<td>
			<a href="page_handler.php?p=2&s=0"
				onmouseover="changeImages('card_rollovers_10', './images/card_rollovers_10-over.jpg'); return true;"
				onmouseout="changeImages('card_rollovers_10', './images/card_rollovers_10.jpg'); return true;"
				onmousedown="changeImages('card_rollovers_10', './images/card_rollovers_10-over.jpg'); return true;"
				onmouseup="changeImages('card_rollovers_10', './images/card_rollovers_10-over.jpg'); return true;">
				<img name="card_rollovers_10" src="images/card_rollovers_10.jpg" width="79" height="149" border="0" alt="Alternate05"></a></td>
	</tr>
</table>		</td>
        <td width="380"><br />
			<table width="380" border="0" cellpadding="8" cellspacing="0" class="GrayTable">
			  <tr>
			    <td><img src="images/OurCompany.gif" width="380" height="50" />
		        <p>Cardozo Engineering, Inc. (CE) is a Hispanic-owned <strong>civil and environmental engineering</strong> firm founded in 1999. CEs area of expertise is in providing engineering planning, design and construction management services on municipal water, sewer, and stormwater transmission and treatment facilities. CE staff has prepared master plans, conducted CMOM studies, managed SSES programs and designed and managed the construction of pipelines, pump stations and treatment facilities ranging from under $100K up to $100 million. We currently serve municipal clients in Florida.</p>
<p><em><strong><a href="http://www.cardozo.com/page_handler.php?p=3&amp;s=0"><br></a> </strong></em></p>
<p>&nbsp;</p>
</td>
		      </tr>
			  <tr>
				<td>&nbsp;</td>
			  </tr>
			</table>
		</td>
      </tr>
    </table></td>
  </tr>
  <tr>
    <td height="28" colspan="2">
	<link href="./cardozo_styles.css" rel="stylesheet" type="text/css">
<table width="95%" border="0" align="center" cellpadding="4" cellspacing="0" bgcolor="#FFFFFF">
  <tr>
    <td colspan="2" valign="top"><div align="center">
      <hr align="center" noshade>
    </div></td>
  </tr>
  <tr>
    <td valign="top"><strong class="expanded">&copy; 1999 - 2023 cardozo engineering inc.</strong></td>
    <td valign="top" class="expanded" align="right"><a href="http://www.cardozo-eng.com"><strong>www.cardozo-eng.com</strong></a> website<br>
    <a href="/cdn-cgi/l/email-protection#6e070008012e0d0f1c0a011401430b0009400d0103"><strong><span class="__cf_email__" data-cfemail="7910171f16391a180b1d160316541c171e571a1614">[email&#160;protected]</span></strong></a> email</td>
  </tr>
</table>
	</td>
  </tr>
</table>
<script data-cfasync="false" src="/cdn-cgi/scripts/5c5dd728/cloudflare-static/email-decode.min.js"></script></body>
</html>
